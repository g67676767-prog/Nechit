package com.autododge

import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.sqrt

/** Цвет «жёлтая/золотистая/оранжевая пуля»: оттенок 20–68°, насыщенность и яркость выше порогов (0..255). */
internal fun isBulletTone(r: Int, g: Int, b: Int, satMin: Int, vMin: Int): Boolean {
    val mx = maxOf(r, g, b)
    val mn = minOf(r, g, b)
    val d = mx - mn
    if (mx < vMin || d <= 0 || d * 255 < satMin * mx || b == mx) return false
    val hue = if (r >= g) {
        if (g < b) return false
        60 * (g - b) / d
    } else {
        120 + 60 * (b - r) / d
    }
    return hue in 20..68
}

/**
 * Ищет жёлтые/оранжевые вытянутые пятна (HSV-порог + компоненты связности + PCA-вытянутость).
 * Читает RGBA-байты кадра напрямую. Без OpenCV, чтобы не тянуть нативные зависимости.
 */
class ProjectileDetector {
    private var mask = BooleanArray(0)
    private var stack = IntArray(0)

    fun detect(f: Frame, sensitivityPct: Float): List<Blob> {
        val w = f.w
        val h = f.h
        val n = w * h
        if (mask.size < n) { mask = BooleanArray(n); stack = IntArray(n) }
        val sens = (sensitivityPct / 100f).coerceIn(0f, 1f)
        val satMin = ((0.70f - 0.40f * sens) * 255).toInt()
        val vMin = ((0.75f - 0.35f * sens) * 255).toInt()
        val d = f.data

        for (y in 0 until h) {
            var i = y * f.stride
            var m = y * w
            for (x in 0 until w) {
                mask[m] = isBulletTone(d[i].toInt() and 255, d[i + 1].toInt() and 255, d[i + 2].toInt() and 255, satMin, vMin)
                i += 4
                m++
            }
        }

        val out = ArrayList<Blob>()
        val maxArea = n / 60
        for (start in 0 until n) {
            if (!mask[start]) continue
            var sp = 0
            stack[sp++] = start
            mask[start] = false
            var cnt = 0
            var sx = 0.0; var sy = 0.0; var sxx = 0.0; var syy = 0.0; var sxy = 0.0
            var minX = Int.MAX_VALUE; var minY = Int.MAX_VALUE; var maxX = -1; var maxY = -1
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w
                val y = i / w
                cnt++
                sx += x; sy += y; sxx += x.toDouble() * x; syy += y.toDouble() * y; sxy += x.toDouble() * y
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                if (x > 0 && mask[i - 1]) { mask[i - 1] = false; stack[sp++] = i - 1 }
                if (x < w - 1 && mask[i + 1]) { mask[i + 1] = false; stack[sp++] = i + 1 }
                if (y > 0 && mask[i - w]) { mask[i - w] = false; stack[sp++] = i - w }
                if (y < h - 1 && mask[i + w]) { mask[i + w] = false; stack[sp++] = i + w }
            }
            if (cnt < 8 || cnt > maxArea) continue
            val cx = sx / cnt
            val cy = sy / cnt
            val a = sxx / cnt - cx * cx
            val c = syy / cnt - cy * cy
            val b = sxy / cnt - cx * cy
            val tr = (a + c) / 2
            val dd = sqrt(((a - c) / 2) * ((a - c) / 2) + b * b)
            val l1 = tr + dd
            val l2 = max(tr - dd, 0.05)
            val elong = sqrt(l1 / l2).toFloat()
            if (elong < 1.8f) continue
            val angle = (0.5 * atan2(2 * b, a - c)).toFloat()
            out.add(Blob(cx.toFloat(), cy.toFloat(), minX.toFloat(), minY.toFloat(),
                (maxX + 1).toFloat(), (maxY + 1).toFloat(), angle, elong, cnt))
        }
        return out
    }
}
