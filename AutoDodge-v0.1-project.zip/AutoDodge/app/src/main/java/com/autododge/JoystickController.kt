package com.autododge

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import kotlin.math.cos
import kotlin.math.sin

interface JoystickController {
    val isAvailable: Boolean
    fun move(angle: Float, s: Settings, sw: Int, sh: Int)
    fun release()
}

class AutoDodgeAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: AutoDodgeAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun send(g: GestureDescription, cb: GestureResultCallback): Boolean = dispatchGesture(g, cb, null)
}

/**
 * Удерживает палец на джойстике непрерывно: первый сегмент жеста нажимает в центре и тянет к цели,
 * следующие сегменты продолжают тот же жест (continueStroke) и меняют цель. Когда команда пропадает
 * (или 400 мс нет новых команд) — палец отпускается. Все состояния трогаются только в главном потоке.
 */
class AccessibilityJoystickController : JoystickController {
    private val main = Handler(Looper.getMainLooper())
    private var stroke: GestureDescription.StrokeDescription? = null
    private var curX = 0f
    private var curY = 0f
    private var inFlight = false
    private var wanted = false
    private var wantX = 0f
    private var wantY = 0f
    private var startX = 0f
    private var startY = 0f
    private var segMs = 100L
    private var maxX = 1000f
    private var maxY = 1000f
    private var lastWantMs = 0L

    override val isAvailable: Boolean get() = AutoDodgeAccessibilityService.instance != null

    override fun move(angle: Float, s: Settings, sw: Int, sh: Int) {
        val jx = if (s.joyX < 0) sw * 0.15f else s.joyX
        val jy = if (s.joyY < 0) sh * 0.72f else s.joyY
        val len = s.joyRadius * (s.joyStrength / 100f)
        val tx = jx + cos(angle) * len
        val ty = jy + sin(angle) * len
        val ms = s.gestureMs.toLong().coerceIn(30L, 300L)
        main.post {
            startX = jx
            startY = jy
            maxX = (sw - 1).toFloat()
            maxY = (sh - 1).toFloat()
            wantX = tx.coerceIn(0f, maxX)
            wantY = ty.coerceIn(0f, maxY)
            segMs = ms
            wanted = true
            lastWantMs = SystemClock.uptimeMillis()
            pump()
        }
    }

    override fun release() {
        main.post { wanted = false; pump() }
    }

    private fun pump() {
        if (inFlight) return
        val svc = AutoDodgeAccessibilityService.instance
        if (svc == null) { stroke = null; wanted = false; return }
        if (wanted && SystemClock.uptimeMillis() - lastWantMs > 400L) wanted = false
        val prev = stroke
        if (wanted) {
            val path = Path()
            val st: GestureDescription.StrokeDescription
            if (prev == null) {
                path.moveTo(startX.coerceIn(0f, maxX), startY.coerceIn(0f, maxY))
                path.lineTo(wantX, wantY)
                st = GestureDescription.StrokeDescription(path, 0L, segMs, true)
            } else {
                path.moveTo(curX, curY)
                path.lineTo(wantX, wantY)
                st = prev.continueStroke(path, 0L, segMs, true)
            }
            dispatch(svc, st, wantX, wantY, true)
        } else if (prev != null) {
            val path = Path()
            path.moveTo(curX, curY)
            dispatch(svc, prev.continueStroke(path, 0L, 20L, false), curX, curY, false)
        }
    }

    private fun dispatch(
        svc: AutoDodgeAccessibilityService,
        st: GestureDescription.StrokeDescription,
        ex: Float, ey: Float, cont: Boolean
    ) {
        inFlight = true
        val g = GestureDescription.Builder().addStroke(st).build()
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                main.post {
                    inFlight = false
                    if (cont) { stroke = st; curX = ex; curY = ey } else { stroke = null }
                    pump()
                }
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                main.post { inFlight = false; stroke = null; pump() }
            }
        }
        if (!svc.send(g, cb)) { inFlight = false; stroke = null }
    }
}
