package com.autododge

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private class Field(val label: String, val get: (Settings) -> Float, val set: (Settings, Float) -> Settings)

    private val fields = listOf(
        Field("Радиус коллизии персонажа, px", { it.charRadius }, { s, v -> s.copy(charRadius = v) }),
        Field("Радиус пули, px", { it.projRadius }, { s, v -> s.copy(projRadius = v) }),
        Field("Чувствительность, %", { it.sensitivity }, { s, v -> s.copy(sensitivity = v) }),
        Field("Запас времени для реакции, %", { it.reaction }, { s, v -> s.copy(reaction = v) }),
        Field("Скорость персонажа, px/с", { it.charSpeed }, { s, v -> s.copy(charSpeed = v) }),
        Field("Персонаж X (-1 = центр)", { it.charX }, { s, v -> s.copy(charX = v) }),
        Field("Персонаж Y (-1 = центр)", { it.charY }, { s, v -> s.copy(charY = v) }),
        Field("Джойстик X (-1 = оценка)", { it.joyX }, { s, v -> s.copy(joyX = v) }),
        Field("Джойстик Y (-1 = оценка)", { it.joyY }, { s, v -> s.copy(joyY = v) }),
        Field("Радиус джойстика, px", { it.joyRadius }, { s, v -> s.copy(joyRadius = v) }),
        Field("Сила жеста, % радиуса", { it.joyStrength }, { s, v -> s.copy(joyStrength = v) }),
        Field("Сегмент удержания джойстика, мс (меньше = быстрее реакция)", { it.gestureMs }, { s, v -> s.copy(gestureMs = v) }),
        Field("Задержка управления, мс (от жеста до движения)", { it.controlDelayMs }, { s, v -> s.copy(controlDelayMs = v) }),
        Field("Масштаб захвата, % (ниже = быстрее)", { it.captureScale }, { s, v -> s.copy(captureScale = v) })
    )
    private val edits = ArrayList<EditText>()
    private lateinit var repo: SettingsRepository
    private val REQ_CAPTURE = 42

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        repo = SettingsRepository(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        root.addView(TextView(this).apply {
            text = "Auto-Dodge v0.2 — тестовый инструмент.\nСначала диагностика (без управления), затем эксперимент с «Авто»."
        })
        root.addView(button("1. Разрешить окна поверх приложений") {
            startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("2. Запустить панель (запрос захвата экрана)") { startPanel() })
        root.addView(button("3. Служба доступности (для «Авто»)") {
            startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("Остановить сервис") {
            startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        })
        val s = repo.load()
        for (f in fields) {
            root.addView(TextView(this).apply { text = f.label; setPadding(0, 24, 0, 0) })
            val e = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
                setText(f.get(s).toString())
            }
            edits.add(e); root.addView(e)
        }
        root.addView(button("Сохранить настройки") { save() })
        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    private fun button(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    private fun save() {
        var s = repo.load()
        for ((i, f) in fields.withIndex()) edits[i].text.toString().toFloatOrNull()?.let { s = f.set(s, it) }
        repo.save(s)
        Toast.makeText(this, "Сохранено (применится при «Отслеживать»)", Toast.LENGTH_SHORT).show()
    }

    private fun startPanel() {
        if (!AndroidSettings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала шаг 1: разрешение «поверх окон»", Toast.LENGTH_LONG).show(); return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        @Suppress("DEPRECATION")
        startActivityForResult((getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        @Suppress("DEPRECATION") super.onActivityResult(req, res, data)
        if (req == REQ_CAPTURE) {
            if (res == RESULT_OK && data != null) {
                startForegroundService(Intent(this, CaptureService::class.java)
                    .setAction(CaptureService.ACTION_START)
                    .putExtra(CaptureService.EXTRA_CODE, res).putExtra(CaptureService.EXTRA_DATA, data))
                Toast.makeText(this, "Панель запущена. Откройте игру.", Toast.LENGTH_LONG).show()
            } else Toast.makeText(this, "Разрешение на захват не выдано", Toast.LENGTH_LONG).show()
        }
    }
}
