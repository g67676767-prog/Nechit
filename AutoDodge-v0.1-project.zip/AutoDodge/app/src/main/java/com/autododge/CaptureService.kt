package com.autododge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PointF
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.PI
import kotlin.math.hypot

/** Конвейер: Capture → Detector → Tracker → CharacterDetector → Predictor → Planner → (Joystick, только если «Авто» включено). */
class CaptureService : Service(), OverlayController.Callbacks {
    companion object {
        const val ACTION_START = "start"; const val ACTION_STOP = "stop"
        const val EXTRA_CODE = "code"; const val EXTRA_DATA = "data"
        @Volatile var isRunning = false
    }

    private lateinit var repo: SettingsRepository
    @Volatile private var settings = Settings()
    private var projection: MediaProjection? = null
    private var capture: ScreenCaptureManager? = null
    private var thread: HandlerThread? = null
    private var overlay: OverlayController? = null
    private val main = Handler(Looper.getMainLooper())
    private val detector = ProjectileDetector()
    private val tracker = ProjectileTracker()
    private val charDet = CharacterDetector()
    private val predictor = CollisionPredictor()
    private val planner = DodgePlanner()
    private val joystick: JoystickController = AccessibilityJoystickController()
    @Volatile private var tracking = false
    @Volatile private var armed = false
    @Volatile private var learnReq: PointF? = null
    private var calibStep = -1
    private var screenW = 0; private var screenH = 0; private var dpi = 320
    private var avgMs = 0f
    private var lastUiMs = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown(); return START_NOT_STICKY }
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        startForegroundCompat() // обязательно после startForegroundService, даже при повторном запуске
        if (isRunning) return START_NOT_STICKY
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        repo = SettingsRepository(this)
        settings = repo.load()
        readScreen()
        val mp = (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code, data)
        projection = mp
        thread = HandlerThread("dodge-proc", android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY).also { it.start() }
        capture = ScreenCaptureManager(mp, Handler(thread!!.looper), this::onFrame) { main.post { shutdown() } }
            .also { it.start(screenW, screenH, dpi, settings.captureScale) }
        overlay = OverlayController(this, this).also { it.show() }
        isRunning = true
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("dodge", "Auto-Dodge", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "dodge").setContentTitle("Auto-Dodge")
            .setContentText("Захват экрана активен").setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun readScreen() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds; screenW = b.width(); screenH = b.height()
        } else {
            val dm = DisplayMetrics(); @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels; screenH = dm.heightPixels
        }
        dpi = resources.displayMetrics.densityDpi
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (!isRunning) return
        readScreen()
        tracker.reset(); planner.reset(); charDet.markLost()
        capture?.resize(screenW, screenH, settings.captureScale)
    }

    // ---- конвейер (фоновый поток, приоритет URGENT_DISPLAY) ----
    private fun onFrame(f: Frame, tNs: Long) {
        val req = learnReq
        if (!tracking && req == null) return
        val s = settings
        val k = screenW.toFloat() / f.w

        if (req != null) {
            learnReq = null
            val ok = charDet.learn(f, req.x / k, req.y / k, s.charRadius / k, tNs)
            main.post {
                overlay?.setStatus(if (ok) "Персонаж запомнен, слежение включено" else "Не удалось запомнить персонажа: слабый контраст с фоном")
            }
            if (!tracking) { capture?.setActive(false); return }
        }

        val t0 = System.nanoTime()
        var age = (t0 - tNs) / 1e9f // возраст кадра к моменту обработки
        if (age < 0f || age > 0.25f) age = 0.016f

        val blobs = detector.detect(f, s.sensitivity).map { it.scaled(k) }
        val tracks = tracker.update(blobs, tNs)

        var chx = 0f
        var chy = 0f
        var cvx = 0f
        var cvy = 0f
        var mode = 0
        if (charDet.hasModel) {
            charDet.track(f, tNs, s.charRadius / k, s.charSpeed / k)
            chx = charDet.posX * k
            chy = charDet.posY * k
            if (charDet.lost) {
                mode = 2
            } else {
                mode = 1
                cvx = charDet.vx * k
                cvy = charDet.vy * k
            }
        } else {
            val p = charDet.position(s, screenW, screenH)
            chx = p.x
            chy = p.y
        }

        // Полная задержка: возраст кадра + обработка + доставка жеста.
        val lat = age + avgMs / 1000f + s.controlDelayMs / 1000f
        val cap = s.charSpeed * 1.5f
        val sp = hypot(cvx, cvy)
        if (sp > cap && sp > 0f) { cvx *= cap / sp; cvy *= cap / sp }
        val px = (chx + cvx * lat).coerceIn(0f, screenW.toFloat())
        val py = (chy + cvy * lat).coerceIn(0f, screenH.toFloat())

        val threats = predictor.evaluate(tracks, px, py, s, lat)
        val dec = planner.plan(threats, px, py, s, screenW.toFloat(), screenH.toFloat())
        if (armed) { if (dec != null) joystick.move(dec.angle, s, screenW, screenH) else joystick.release() }

        val procMs = (System.nanoTime() - t0) / 1e6f
        avgMs = if (avgMs == 0f) procMs else avgMs * 0.9f + procMs * 0.1f

        val nowMs = SystemClock.uptimeMillis()
        if (nowMs - lastUiMs >= 33L) {
            lastUiMs = nowMs
            val st = DiagState(
                tracks = tracks.map { TrackView(it.id, it.left, it.top, it.right, it.bottom, it.x, it.y, it.vx, it.vy, it.confirmed) },
                threats = threats.map { ThreatView(it.hx, it.hy, it.tHit) },
                charX = chx, charY = chy, charR = s.charRadius, hitR = s.charRadius + s.projRadius,
                charMode = mode, dirAngle = dec?.angle, armed = armed,
                procMs = procMs, avgMs = avgMs, blobs = blobs.size,
                joyX = if (s.joyX < 0) screenW * 0.15f else s.joyX,
                joyY = if (s.joyY < 0) screenH * 0.72f else s.joyY,
                joyR = s.joyRadius
            )
            val msg = "Пуль:${blobs.size} угроз:${threats.size} ${"%.0f".format(avgMs)}мс" +
                (if (armed) (if (dec != null) " АВТО:двигаю" else " АВТО:жду") else "") +
                (if (mode == 2) " ПЕРСОНАЖ ПОТЕРЯН" else "")
            main.post { overlay?.update(st); overlay?.setStatus(msg) }
        }
    }

    // ---- панель ----
    override fun onTrack() {
        settings = repo.load()
        tracker.reset(); planner.reset(); avgMs = 0f
        capture?.resize(screenW, screenH, settings.captureScale)
        tracking = true
        capture?.setActive(true)
        overlay?.setStatus(if (charDet.hasModel) "Отслеживание…" else "Отслеживание (персонаж не запомнен: нажмите «Калибр.»)")
    }

    override fun onStop() {
        tracking = false; armed = false
        joystick.release(); planner.reset()
        capture?.setActive(false)
        overlay?.setArmed(false); overlay?.update(null); overlay?.setStatus("Остановлено")
    }

    override fun onToggleArm(): Boolean {
        if (armed) { armed = false; joystick.release(); return false }
        if (!tracking) { toast("Сначала нажмите «Отслеживать»"); return false }
        if (!joystick.isAvailable) { toast("Включите службу доступности Auto-Dodge в настройках"); return false }
        armed = true
        return true
    }

    override fun onCalibrate() {
        calibStep = 0
        overlay?.setCalibration(true, "Калибровка 1/2: коснитесь центра ПЕРСОНАЖА")
    }

    override fun onCalibTap(x: Float, y: Float) {
        when (calibStep) {
            0 -> {
                settings = settings.copy(charX = x, charY = y)
                learnReq = PointF(x, y)       // цвета персонажа запомнятся по следующему кадру
                capture?.setActive(true)
                calibStep = 1
                overlay?.setCalibration(true, "Калибровка 2/2: коснитесь ЦЕНТРА джойстика")
            }
            1 -> {
                settings = settings.copy(joyX = x, joyY = y)
                calibStep = -1
                repo.save(settings)
                overlay?.setCalibration(false, null)
                toast("Калибровка сохранена")
            }
        }
    }

    /** Проверка управления без распознавания: вправо, влево, вверх, вниз по ~1.2 с. */
    override fun onTestJoystick() {
        if (!joystick.isAvailable) { toast("Служба доступности Auto-Dodge не включена"); return }
        settings = repo.load()
        val angles = floatArrayOf(0f, PI.toFloat(), (-PI / 2).toFloat(), (PI / 2).toFloat())
        var tick = 0
        val r = object : Runnable {
            override fun run() {
                val step = tick / 12
                if (step >= angles.size) {
                    joystick.release()
                    overlay?.setStatus("Тест окончен")
                    return
                }
                joystick.move(angles[step], settings, screenW, screenH)
                tick++
                main.postDelayed(this, 100)
            }
        }
        overlay?.setStatus("Тест: вправо, влево, вверх, вниз")
        main.post(r)
    }

    override fun onSettings() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    override fun onClose() = shutdown()

    private fun toast(t: String) { main.post { Toast.makeText(this, t, Toast.LENGTH_SHORT).show() } }

    private fun shutdown() {
        tracking = false; armed = false
        joystick.release()
        capture?.release(); capture = null
        projection?.stop(); projection = null
        overlay?.hide(); overlay = null
        thread?.quitSafely(); thread = null
        isRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { if (isRunning) shutdown(); super.onDestroy() }
}
