package com.autododge

import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler

/**
 * Кадры через MediaProjection. VirtualDisplay создаётся один раз (Android 14+ не разрешает
 * повторное создание на том же токене); пауза = отключение поверхности.
 * Ограничения частоты нет: берётся самый свежий кадр, старые отбрасываются.
 */
class ScreenCaptureManager(
    private val projection: MediaProjection,
    private val handler: Handler,
    private val onFrame: (Frame, Long) -> Unit,
    private val onProjectionStopped: () -> Unit
) {
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    @Volatile private var active = false
    private var dpi = 320
    private var bytes = ByteArray(0)

    private val callback = object : MediaProjection.Callback() {
        override fun onStop() { release(); onProjectionStopped() }
    }

    private fun createReader(w: Int, h: Int): ImageReader =
        ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2).also { r ->
            r.setOnImageAvailableListener({ handleImage(it) }, handler)
        }

    private fun dims(sw: Int, sh: Int, scalePct: Float): Pair<Int, Int> {
        val k = (scalePct / 100f).coerceIn(0.2f, 1f)
        return Pair(((sw * k).toInt() and 1.inv()).coerceAtLeast(64), ((sh * k).toInt() and 1.inv()).coerceAtLeast(64))
    }

    fun start(sw: Int, sh: Int, dpi: Int, scalePct: Float) {
        this.dpi = dpi
        projection.registerCallback(callback, handler)
        val (w, h) = dims(sw, sh, scalePct)
        val r = createReader(w, h)
        reader = r
        display = projection.createVirtualDisplay(
            "AutoDodge", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
        setActive(false)
    }

    fun setActive(on: Boolean) {
        active = on
        display?.surface = if (on) reader?.surface else null
    }

    /** Поворот экрана / смена масштаба. */
    fun resize(sw: Int, sh: Int, scalePct: Float) {
        val (w, h) = dims(sw, sh, scalePct)
        val old = reader
        val nr = createReader(w, h)
        reader = nr
        display?.resize(w, h, dpi)
        display?.surface = if (active) nr.surface else null
        old?.close()
    }

    private fun handleImage(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            if (!active) return
            val plane = img.planes[0]
            val buf = plane.buffer
            val need = buf.remaining()
            if (bytes.size < need) bytes = ByteArray(need)
            buf.get(bytes, 0, need)
            val ts = if (img.timestamp > 0L) img.timestamp else System.nanoTime()
            onFrame(Frame(bytes, img.width, img.height, plane.rowStride), ts)
        } finally {
            img.close()
        }
    }

    fun release() {
        active = false
        try { projection.unregisterCallback(callback) } catch (_: Exception) {}
        display?.release(); display = null
        reader?.close(); reader = null
    }
}
