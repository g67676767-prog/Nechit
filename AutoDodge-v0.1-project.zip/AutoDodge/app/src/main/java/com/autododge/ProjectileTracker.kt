package com.autododge

import kotlin.math.hypot
import kotlin.math.max

/** Жадное сопоставление блобов с треками по предсказанному положению. */
class ProjectileTracker {
    private val tracks = ArrayList<Track>()
    private var nextId = 1

    private class Pair(val d: Float, val tr: Track, val bi: Int)

    fun reset() { tracks.clear() }

    fun update(blobs: List<Blob>, tNs: Long): List<Track> {
        val pairs = ArrayList<Pair>()
        for (tr in tracks) {
            val dt = (tNs - tr.t) / 1e9f
            val px = tr.x + tr.vx * dt; val py = tr.y + tr.vy * dt
            val gate = max(80f, 1.5f * hypot(tr.vx, tr.vy) * dt + 40f)
            for ((bi, b) in blobs.withIndex()) {
                val d = hypot(b.cx - px, b.cy - py)
                if (d < gate) pairs.add(Pair(d, tr, bi))
            }
        }
        pairs.sortBy { it.d }
        val usedT = HashSet<Int>(); val usedB = HashSet<Int>()
        for (p in pairs) {
            if (p.tr.id in usedT || p.bi in usedB) continue
            usedT.add(p.tr.id); usedB.add(p.bi)
            p.tr.add(blobs[p.bi], tNs)
        }
        val it = tracks.iterator()
        while (it.hasNext()) {
            val tr = it.next()
            if (tr.id !in usedT) {
                tr.misses++
                if (tr.misses > 8 || (tNs - tr.t) > 400_000_000L) it.remove()
            }
        }
        for ((bi, b) in blobs.withIndex()) if (bi !in usedB) tracks.add(Track(nextId++, b, tNs))
        return tracks.filter { it.misses <= 3 }
    }
}
