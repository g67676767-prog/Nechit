package com.autododge

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** 8 направлений + «стоять»; гистерезис против дёргания; учёт границ экрана. */
class DodgePlanner {
    private var last: Float? = null

    fun reset() { last = null }

    fun plan(threats: List<Threat>, cx: Float, cy: Float, s: Settings, w: Float, h: Float): Decision? {
        if (threats.isEmpty()) { last = null; return null }
        val r = s.charRadius + s.projRadius
        val horizon = CollisionPredictor.BASE_HORIZON_S * s.reaction / 100f
        val m = s.charRadius

        fun score(angle: Float?): Float {
            var minClear = Float.MAX_VALUE
            var wall = false
            var t = 0f
            while (t <= horizon) {
                var x = cx; var y = cy
                if (angle != null) {
                    x = cx + cos(angle) * s.charSpeed * t
                    y = cy + sin(angle) * s.charSpeed * t
                    val x2 = x.coerceIn(m, w - m); val y2 = y.coerceIn(m, h - m)
                    if (x2 != x || y2 != y) wall = true
                    x = x2; y = y2
                }
                for (th in threats) {
                    val clear = hypot(th.px + th.vx * t - x, th.py + th.vy * t - y) - r
                    if (clear < minClear) minClear = clear
                }
                t += 0.02f
            }
            return minClear - if (wall) 15f else 0f
        }

        val stay = score(null)
        if (stay >= 0f) { last = null; return null }
        var best: Decision? = null
        for (k in 0 until 16) {
            val a = (k * PI / 8).toFloat()
            val sc = score(a)
            val cur = best
            if (cur == null || sc > cur.score) best = Decision(a, sc)
        }
        val b = best ?: return null
        if (b.score <= stay + 2f) { last = null; return null }
        last?.let { prev ->
            val ps = score(prev)
            if (ps >= b.score - 10f && ps > stay + 2f) return Decision(prev, ps)
        }
        last = b.angle
        return b
    }
}
