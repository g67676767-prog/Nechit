package com.autododge

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Плавающая панель + прозрачный слой диагностики. */
class OverlayController(private val ctx: Context, private val cb: Callbacks) {
    interface Callbacks {
        fun onTrack(); fun onStop(); fun onToggleArm(): Boolean
        fun onCalibrate(); fun onSettings(); fun onClose(); fun onCalibTap(x: Float, y: Float); fun onTestJoystick()
    }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val diag = DiagnosticsView(ctx)
    private lateinit var panel: LinearLayout
    private lateinit var status: TextView
    private lateinit var armBtn: Button
    private lateinit var diagLp: LP
    private lateinit var panelLp: LP
    private var shown = false
    private val baseFlags = LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun btn(text: String, onClick: () -> Unit) = Button(ctx).apply {
        this.text = text; textSize = 11f; isAllCaps = false
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(dp(6), dp(4), dp(6), dp(4))
        setOnClickListener { onClick() }
    }

    fun show() {
        if (shown) return
        diag.onTap = { x, y -> cb.onCalibTap(x, y) }
        diagLp = LP(LP.MATCH_PARENT, LP.MATCH_PARENT, LP.TYPE_APPLICATION_OVERLAY,
            baseFlags or LP.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(diag, diagLp)

        status = TextView(ctx).apply { text = "Готово"; textSize = 11f; setTextColor(Color.WHITE) }
        armBtn = btn("Авто: ВЫКЛ") {
            val on = cb.onToggleArm()
            armBtn.text = if (on) "Авто: ВКЛ" else "Авто: ВЫКЛ"
        }
        val handle = TextView(ctx).apply {
            text = "≡ Auto-Dodge"; textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 0, 0, dp(4))
        }
        panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = GradientDrawable().apply { setColor(Color.argb(200, 20, 20, 30)); cornerRadius = dp(10).toFloat() }
            addView(handle); addView(status)
            addView(row(btn("Отслеживать") { cb.onTrack() }, btn("Стоп") { cb.onStop() }))
            addView(row(armBtn, btn("Калибр.") { cb.onCalibrate() }))
            addView(row(btn("Настр.") { cb.onSettings() }, btn("Тест") { cb.onTestJoystick() }, btn("✕") { cb.onClose() }))
        }
        panelLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY, LP.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(60) }

        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = panelLp.x; sy = panelLp.y }
                MotionEvent.ACTION_MOVE -> {
                    panelLp.x = sx + (e.rawX - dx).toInt(); panelLp.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(panel, panelLp)
                }
            }
            true
        }
        wm.addView(panel, panelLp)
        shown = true
    }

    private fun row(vararg buttons: Button) = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        for (b in buttons) addView(b)
    }

    fun setStatus(t: String) { if (shown) status.text = t }
    fun setArmed(on: Boolean) { if (shown) armBtn.text = if (on) "Авто: ВКЛ" else "Авто: ВЫКЛ" }
    fun update(s: DiagState?) { diag.state = s; diag.invalidate() }

    fun setCalibration(on: Boolean, hint: String?) {
        if (!shown) return
        diag.hint = if (on) hint else null
        diagLp.flags = if (on) baseFlags else baseFlags or LP.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(diag, diagLp)
        diag.invalidate()
    }

    fun hide() {
        if (!shown) return
        try { wm.removeView(panel); wm.removeView(diag) } catch (_: Exception) {}
        shown = false
    }
}
