package com.autododge

import android.content.Context

class SettingsRepository(ctx: Context) {
    private val p = ctx.getSharedPreferences("autododge", Context.MODE_PRIVATE)

    fun load(): Settings {
        val d = Settings()
        return Settings(
            charRadius = p.getFloat("charRadius", d.charRadius),
            projRadius = p.getFloat("projRadius", d.projRadius),
            sensitivity = p.getFloat("sensitivity", d.sensitivity),
            reaction = p.getFloat("reaction", d.reaction),
            charX = p.getFloat("charX", d.charX),
            charY = p.getFloat("charY", d.charY),
            charSpeed = p.getFloat("charSpeed", d.charSpeed),
            joyX = p.getFloat("joyX", d.joyX),
            joyY = p.getFloat("joyY", d.joyY),
            joyRadius = p.getFloat("joyRadius", d.joyRadius),
            joyStrength = p.getFloat("joyStrength", d.joyStrength),
            gestureMs = p.getFloat("gestureMs", d.gestureMs),
            captureScale = p.getFloat("captureScale", d.captureScale),
            controlDelayMs = p.getFloat("controlDelayMs", d.controlDelayMs)
        )
    }

    fun save(s: Settings) {
        p.edit()
            .putFloat("charRadius", s.charRadius).putFloat("projRadius", s.projRadius)
            .putFloat("sensitivity", s.sensitivity).putFloat("reaction", s.reaction)
            .putFloat("charX", s.charX).putFloat("charY", s.charY)
            .putFloat("charSpeed", s.charSpeed)
            .putFloat("joyX", s.joyX).putFloat("joyY", s.joyY)
            .putFloat("joyRadius", s.joyRadius).putFloat("joyStrength", s.joyStrength)
            .putFloat("gestureMs", s.gestureMs).putFloat("captureScale", s.captureScale)
            .putFloat("controlDelayMs", s.controlDelayMs)
            .apply()
    }
}
