package com.autododge

import android.graphics.PointF

/**
 * Слежение за персонажем по цветовой модели. При калибровке (касание по персонажу) запоминаются
 * цвета в круге вокруг точки, которые заметно чаще встречаются в нём, чем в кольце фона вокруг.
 * Дальше в каждом кадре в окне вокруг предсказанного положения ищется центр масс таких пикселей
 * (3 итерации сдвига). При потере — поиск по всему кадру. Работает в пикселях кадра захвата.
 */
class CharacterDetector {
    private val model = BooleanArray(4096)
    var hasModel = false
        private set
    var lost = true
        private set
    var vx = 0f
        private set
    var vy = 0f
        private set

    private var cx = 0f
    private var cy = 0f
    private var offX = 0f
    private var offY = 0f
    private var minCount = 6
    private var lastT = 0L
    private var lostFrames = 0
    private var mX = 0f
    private var mY = 0f

    /** Центр коллизии (центр масс + смещение, заданное при калибровке). */
    val posX: Float get() = cx + offX
    val posY: Float get() = cy + offY

    /** Запасной вариант, пока персонаж не запомнен: ручная точка или центр экрана. */
    fun position(s: Settings, screenW: Int, screenH: Int): PointF =
        if (s.charX < 0 || s.charY < 0) PointF(screenW / 2f, screenH / 2f) else PointF(s.charX, s.charY)

    fun markLost() { lost = true; vx = 0f; vy = 0f; lostFrames = 0 }

    private fun bin(r: Int, g: Int, b: Int) = ((r shr 4) shl 8) or ((g shr 4) shl 4) or (b shr 4)

    fun learn(f: Frame, px: Float, py: Float, rCap: Float, tNs: Long): Boolean {
        val r = rCap.coerceAtLeast(6f)
        val rIn = r * 0.8f
        val rBgMin = r * 1.5f
        val rBgMax = r * 2.6f
        val fg = IntArray(4096)
        val bg = IntArray(4096)
        var nf = 0
        var nb = 0
        val x0 = (px - rBgMax).toInt().coerceAtLeast(0)
        val x1 = (px + rBgMax).toInt().coerceAtMost(f.w - 1)
        val y0 = (py - rBgMax).toInt().coerceAtLeast(0)
        val y1 = (py + rBgMax).toInt().coerceAtMost(f.h - 1)
        for (y in y0..y1) {
            for (x in x0..x1) {
                val dx = x - px
                val dy = y - py
                val d2 = dx * dx + dy * dy
                val inFg = d2 <= rIn * rIn
                val inBg = d2 >= rBgMin * rBgMin && d2 <= rBgMax * rBgMax
                if (!inFg && !inBg) continue
                val i = y * f.stride + x * 4
                val rr = f.data[i].toInt() and 255
                val gg = f.data[i + 1].toInt() and 255
                val bb = f.data[i + 2].toInt() and 255
                if (isBulletTone(rr, gg, bb, 100, 130)) continue
                val bi = bin(rr, gg, bb)
                if (inFg) { fg[bi]++; nf++ } else { bg[bi]++; nb++ }
            }
        }
        if (nf < 10) return false
        model.fill(false)
        var learned = 0
        for (b in 0 until 4096) {
            if (fg[b] < 3) continue
            val ff = fg[b].toFloat() / nf
            val bf = if (nb > 0) bg[b].toFloat() / nb else 0f
            if (ff > 2.5f * bf) { model[b] = true; learned += fg[b] }
        }
        if (learned < 10) return false
        val n = measure(f, px, py, r * 1.3f)
        if (n < 6) return false
        hasModel = true
        cx = mX; cy = mY
        offX = px - mX; offY = py - mY
        minCount = maxOf(5, n / 5)
        lost = false
        vx = 0f; vy = 0f
        lastT = tNs
        lostFrames = 0
        return true
    }

    /** Подсчёт пикселей модели в круге; центр масс кладёт в mX/mY. */
    private fun measure(f: Frame, px: Float, py: Float, rad: Float): Int {
        val x0 = (px - rad).toInt().coerceAtLeast(0)
        val x1 = (px + rad).toInt().coerceAtMost(f.w - 1)
        val y0 = (py - rad).toInt().coerceAtLeast(0)
        val y1 = (py + rad).toInt().coerceAtMost(f.h - 1)
        val r2 = rad * rad
        var n = 0
        var sx = 0L
        var sy = 0L
        for (y in y0..y1) {
            var i = y * f.stride + x0 * 4
            val dy = y - py
            for (x in x0..x1) {
                val dx = x - px
                if (dx * dx + dy * dy <= r2) {
                    val rr = f.data[i].toInt() and 255
                    val gg = f.data[i + 1].toInt() and 255
                    val bb = f.data[i + 2].toInt() and 255
                    if (model[bin(rr, gg, bb)]) { n++; sx += x; sy += y }
                }
                i += 4
            }
        }
        if (n > 0) { mX = sx.toFloat() / n; mY = sy.toFloat() / n }
        return n
    }

    /** speedCap — максимальная скорость персонажа в px кадра/с. Возвращает true, если персонаж найден. */
    fun track(f: Frame, tNs: Long, rCap: Float, speedCap: Float): Boolean {
        if (!hasModel) return false
        val dt = ((tNs - lastT) / 1e9f).coerceIn(0f, 0.25f)
        val r = rCap.coerceAtLeast(6f)
        val rMatch = r * 1.8f
        val wasLost = lost
        var px = cx + vx * dt
        var py = cy + vy * dt
        var found = false
        if (!lost) {
            var rad = rMatch + speedCap * dt * 1.5f + 3f
            for (iter in 0 until 3) {
                val n = measure(f, px, py, rad)
                if (n < minCount) break
                found = true
                px = mX; py = mY
                rad = rMatch
            }
        }
        if (!found) {
            lostFrames++
            if (wasLost && lostFrames % 3 == 0) found = reacquire(f, r, tNs).also { if (it) { px = mX; py = mY } }
        }
        if (found) {
            if (!wasLost && dt >= 0.008f) {
                var nvx = 0.5f * vx + 0.5f * (px - cx) / dt
                var nvy = 0.5f * vy + 0.5f * (py - cy) / dt
                val sp = kotlin.math.hypot(nvx, nvy)
                val cap = speedCap * 1.5f
                if (sp > cap && sp > 0f) { nvx *= cap / sp; nvy *= cap / sp }
                vx = nvx; vy = nvy
            } else {
                vx = 0f; vy = 0f
            }
            cx = px; cy = py
            lost = false
            lastT = tNs
            lostFrames = 0
        } else {
            lost = true
            vx *= 0.5f; vy *= 0.5f
        }
        return found
    }

    /** Поиск по всему кадру: самая «плотная» ячейка совпадающих пикселей. Результат — в mX/mY. */
    private fun reacquire(f: Frame, r: Float, tNs: Long): Boolean {
        val cell = maxOf(8, r.toInt())
        val gw = f.w / cell + 1
        val gh = f.h / cell + 1
        val counts = IntArray(gw * gh)
        var y = 0
        while (y < f.h) {
            var x = 0
            var i = y * f.stride
            while (x < f.w) {
                val rr = f.data[i].toInt() and 255
                val gg = f.data[i + 1].toInt() and 255
                val bb = f.data[i + 2].toInt() and 255
                if (model[bin(rr, gg, bb)]) counts[(y / cell) * gw + x / cell]++
                x += 3
                i += 12
            }
            y += 3
        }
        var best = -1
        var bc = 0
        for (k in counts.indices) if (counts[k] > bc) { bc = counts[k]; best = k }
        if (best < 0 || bc < 3) return false
        var px = (best % gw) * cell + cell / 2f
        var py = (best / gw) * cell + cell / 2f
        for (iter in 0 until 3) {
            if (measure(f, px, py, r * 1.5f) < minCount) return false
            px = mX; py = mY
        }
        lastT = tNs
        return true
    }
}
