package com.autododge

import kotlin.math.sqrt

class CollisionPredictor {
    companion object { const val BASE_HORIZON_S = 1.2f }

    /** Прямолинейный прогноз. latencyS — задержка обработки+управления: пули сдвигаются вперёд. */
    fun evaluate(tracks: List<Track>, cx: Float, cy: Float, s: Settings, latencyS: Float): List<Threat> {
        val r = s.charRadius + s.projRadius
        val horizon = BASE_HORIZON_S * s.reaction / 100f
        val out = ArrayList<Threat>()
        for (tr in tracks) {
            if (!tr.confirmed) continue
            val px = tr.x + tr.vx * latencyS; val py = tr.y + tr.vy * latencyS
            val dx = px - cx; val dy = py - cy
            val a = tr.vx * tr.vx + tr.vy * tr.vy
            if (a < 1f) continue
            val c = dx * dx + dy * dy - r * r
            val tHit: Float
            if (c <= 0f) {
                tHit = 0f
            } else {
                val b = 2f * (dx * tr.vx + dy * tr.vy)
                if (b >= 0f) continue            // удаляется
                val disc = b * b - 4f * a * c
                if (disc < 0f) continue          // гарантированно мимо
                tHit = (-b - sqrt(disc)) / (2f * a)
            }
            if (tHit <= horizon) out.add(Threat(tr, tHit, px + tr.vx * tHit, py + tr.vy * tHit, px, py, tr.vx, tr.vy))
        }
        return out.sortedBy { it.tHit }
    }
}
