package com.autododge

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * DiagnosticsScreen: рисует найденные пули, прогноз, зону коллизии и выбранное направление.
 * ВАЖНО: слой попадает в захват экрана, поэтому здесь нет жёлтых/оранжевых цветов
 * (оттенок 20–68°), иначе детектор принимал бы собственную графику за пули.
 */
class DiagnosticsView(ctx: Context) : View(ctx) {
    @Volatile var state: DiagState? = null
    var hint: String? = null
    var onTap: ((Float, Float) -> Unit)? = null

    private fun paint(color: Int, w: Float = 3f, fill: Boolean = false) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color; strokeWidth = w; style = if (fill) Paint.Style.FILL else Paint.Style.STROKE
    }
    private val pChar = paint(Color.CYAN, 3f)
    private val pLost = paint(Color.rgb(255, 40, 40), 3f)
    private val pManual = paint(Color.rgb(120, 160, 255), 3f)
    private val pHit = paint(Color.argb(160, 0, 255, 255), 2f)
    private val pBox = paint(Color.MAGENTA, 3f)
    private val pStatic = paint(Color.GRAY, 2f)
    private val pTraj = paint(Color.rgb(170, 100, 255), 3f)
    private val pThreat = paint(Color.rgb(255, 40, 40), 4f)
    private val pDir = paint(Color.GREEN, 8f)
    private val pJoy = paint(Color.argb(120, 0, 255, 0), 2f)
    private val pText = paint(Color.WHITE, 1f, true).apply { textSize = 30f; setShadowLayer(4f, 0f, 0f, Color.BLACK) }

    override fun onDraw(c: Canvas) {
        hint?.let { c.drawText(it, 40f, 260f, pText) }
        val s = state ?: return
        val pc = when (s.charMode) { 1 -> pChar; 2 -> pLost; else -> pManual }
        c.drawCircle(s.charX, s.charY, s.charR, pc)
        c.drawCircle(s.charX, s.charY, s.hitR, pHit)
        c.drawCircle(s.joyX, s.joyY, s.joyR, pJoy)
        for (t in s.tracks) {
            c.drawRect(t.l, t.t, t.r, t.b, if (t.confirmed) pBox else pStatic)
            if (t.confirmed) c.drawLine(t.x, t.y, t.x + t.vx * 1.5f, t.y + t.vy * 1.5f, pTraj)
        }
        for (th in s.threats) {
            c.drawCircle(th.hx, th.hy, 14f, pThreat)
            c.drawLine(th.hx - 14f, th.hy - 14f, th.hx + 14f, th.hy + 14f, pThreat)
            c.drawLine(th.hx - 14f, th.hy + 14f, th.hx + 14f, th.hy - 14f, pThreat)
        }
        s.dirAngle?.let { a ->
            c.drawLine(s.charX, s.charY, s.charX + cos(a) * 120f, s.charY + sin(a) * 120f, pDir)
        }
        val chText = when (s.charMode) { 1 -> "персонаж: слежение"; 2 -> "персонаж: ПОТЕРЯН"; else -> "персонаж: ручная точка" }
        c.drawText(
            "blobs=${s.blobs} proc=${"%.1f".format(s.procMs)}мс avg=${"%.1f".format(s.avgMs)}мс " +
                (if (s.armed) "АВТО" else "ДИАГНОСТИКА"), 40f, 140f, pText
        )
        c.drawText(chText, 40f, 180f, pText)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (hint != null && e.action == MotionEvent.ACTION_DOWN) onTap?.invoke(e.rawX, e.rawY)
        return true
    }
}
