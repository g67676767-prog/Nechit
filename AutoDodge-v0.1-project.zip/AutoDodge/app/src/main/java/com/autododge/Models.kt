package com.autododge

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Все расстояния — в пикселях экрана устройства. */
data class Settings(
    val charRadius: Float = 24f,
    val projRadius: Float = 13f,
    val sensitivity: Float = 80f,   // %
    val reaction: Float = 100f,     // % запаса времени
    val charX: Float = -1f,         // последняя ручная точка; -1 = центр экрана
    val charY: Float = -1f,
    val charSpeed: Float = 350f,    // px/с, скорость персонажа (калибруется)
    val joyX: Float = -1f,          // -1 = грубая оценка (левая часть экрана)
    val joyY: Float = -1f,
    val joyRadius: Float = 120f,
    val joyStrength: Float = 80f,   // % от радиуса
    val gestureMs: Float = 50f,     // длительность сегмента удержания (меньше = быстрее смена направления)
    val captureScale: Float = 50f,  // % от размера экрана
    val controlDelayMs: Float = 40f // оценка задержки «жест → движение персонажа»
)

/** Кадр RGBA_8888 как есть (без копирования в IntArray). */
class Frame(val data: ByteArray, val w: Int, val h: Int, val stride: Int)

data class Blob(
    val cx: Float, val cy: Float,
    val left: Float, val top: Float, val right: Float, val bottom: Float,
    val angle: Float, val elong: Float, val area: Int
) {
    fun scaled(k: Float) = Blob(cx * k, cy * k, left * k, top * k, right * k, bottom * k, angle, elong, area)
}

data class Sample(val x: Float, val y: Float, val t: Long)

class Track(val id: Int, b: Blob, tNs: Long) {
    val samples = ArrayList<Sample>()
    var x = 0f; var y = 0f; var t = 0L
    var vx = 0f; var vy = 0f
    var hits = 0; var misses = 0
    var confirmed = false
    var left = 0f; var top = 0f; var right = 0f; var bottom = 0f
    private var angle = 0f
    private var elong = 1f

    init { add(b, tNs) }

    fun add(b: Blob, tNs: Long) {
        samples.add(Sample(b.cx, b.cy, tNs))
        if (samples.size > 6) samples.removeAt(0)
        x = b.cx; y = b.cy; t = tNs
        angle = b.angle; elong = b.elong
        left = b.left; top = b.top; right = b.right; bottom = b.bottom
        hits++; misses = 0
        val f = samples.first()
        val dt = (tNs - f.t) / 1e9f
        var aligned = false
        if (dt >= 0.012f) {
            val dx = x - f.x
            val dy = y - f.y
            var nvx = dx / dt
            var nvy = dy / dt
            val dist = hypot(dx, dy)
            // Пуля летит вдоль своей оси: направление берём из оси пятна, скорость — проекция смещения.
            // Это даёт устойчивую скорость уже по 2 кадрам.
            if (elong >= 2.0f && dist > 0.5f) {
                val ax = cos(angle)
                val ay = sin(angle)
                val proj = dx * ax + dy * ay
                if (abs(proj) >= 0.8f * dist) {
                    val sp = proj / dt
                    nvx = ax * sp
                    nvy = ay * sp
                    aligned = true
                }
            }
            vx = nvx; vy = nvy
        }
        val travel = hypot(x - f.x, y - f.y)
        val speed = hypot(vx, vy)
        confirmed = if (aligned) hits >= 2 && speed >= FAST_SPEED && travel >= FAST_TRAVEL
        else hits >= 3 && speed >= MIN_SPEED && travel >= MIN_TRAVEL
    }

    companion object {
        const val MIN_SPEED = 80f; const val MIN_TRAVEL = 12f
        const val FAST_SPEED = 120f; const val FAST_TRAVEL = 5f
    }
}

data class Threat(val track: Track, val tHit: Float, val hx: Float, val hy: Float,
                  val px: Float, val py: Float, val vx: Float, val vy: Float)

data class Decision(val angle: Float, val score: Float)

data class TrackView(val id: Int, val l: Float, val t: Float, val r: Float, val b: Float,
                     val x: Float, val y: Float, val vx: Float, val vy: Float, val confirmed: Boolean)
data class ThreatView(val hx: Float, val hy: Float, val tHit: Float)

data class DiagState(
    val tracks: List<TrackView>, val threats: List<ThreatView>,
    val charX: Float, val charY: Float, val charR: Float, val hitR: Float,
    val charMode: Int, // 0 = ручная точка, 1 = слежение, 2 = потерян
    val dirAngle: Float?, val armed: Boolean,
    val procMs: Float, val avgMs: Float, val blobs: Int,
    val joyX: Float, val joyY: Float, val joyR: Float
)
